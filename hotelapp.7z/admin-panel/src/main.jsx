import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import Users from './pages/Users'
import Hotels from './pages/Hotels'
import Bookings from './pages/Bookings'
import './styles.css'

function App(){
  return (<BrowserRouter>
    <nav className="nav"><Link to="/">Users</Link><Link to="/hotels">Hotels</Link><Link to="/bookings">Bookings</Link></nav>
    <Routes>
      <Route path="/" element={<Users/>} />
      <Route path="/hotels" element={<Hotels/>} />
      <Route path="/bookings" element={<Bookings/>} />
    </Routes>
  </BrowserRouter>)
}
createRoot(document.getElementById('root')).render(<App />)

import React, { useEffect, useState } from 'react'
import axios from 'axios'

export default function Dashboard(){
  const [hotels, setHotels] = useState([])
  useEffect(()=>{ axios.get('/api/hotels').then(r=>setHotels(r.data)) },[])
  return (
    <div className="page">
      <h1>Hotel Partner Dashboard</h1>
      <div className="grid">{hotels.map(h=> (
        <div className="card" key={h.id}><h3>{h.name}</h3><p>{h.city}</p></div>
      ))}</div>
    </div>
  )
}

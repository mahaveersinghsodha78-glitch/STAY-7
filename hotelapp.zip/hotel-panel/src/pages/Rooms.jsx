import React, { useEffect, useState } from 'react'
import axios from 'axios'

export default function Rooms(){
  const [hotels, setHotels] = useState([])
  const [selected, setSelected]=useState(null)
  const [rooms, setRooms]=useState([])

  useEffect(()=>{ axios.get('/api/hotels').then(r=>setHotels(r.data)) },[])
  useEffect(()=>{ if(selected) axios.get(`/api/hotels/${selected}/rooms`).then(r=>setRooms(r.data)) },[selected])

  return (
    <div className="page">
      <h1>Rooms</h1>
      <select onChange={e=>setSelected(e.target.value)}>
        <option value="">Select hotel</option>
        {hotels.map(h=>(<option key={h.id} value={h.id}>{h.name} ({h.city})</option>))}
      </select>
      <div className="grid">{rooms.map(r=> (<div className="card" key={r.id}><h4>{r.type}</h4><p>₹{r.price}</p><p>Avail: {r.availableRooms}</p></div>))}</div>
    </div>
  )
}

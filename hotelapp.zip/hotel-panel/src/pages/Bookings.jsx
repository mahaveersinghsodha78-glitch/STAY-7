import React, { useEffect, useState } from 'react'
import axios from 'axios'

export default function Bookings(){
  const [bookings, setBookings] = useState([])
  useEffect(()=>{ axios.get('/api/bookings/user/1').then(r=>setBookings(r.data)) },[])
  return (
    <div className="page">
      <h1>Bookings (sample for user 1)</h1>
      <div className="grid">{bookings.map(b=>(<div className="card" key={b.id}><h4>{b.hotel?.name || 'Hotel'}</h4><p>{b.guestName}</p><p>{b.checkIn} → {b.checkOut}</p></div>))}</div>
    </div>
  )
}

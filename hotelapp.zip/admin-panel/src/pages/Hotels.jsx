import React, { useEffect, useState } from 'react'
import axios from 'axios'
export default function Hotels(){
  const [hotels,setHotels]=useState([])
  useEffect(()=>{ axios.get('/api/hotels').then(r=>setHotels(r.data)) },[])
  return (<div className="page"><h1>Hotels</h1><div className="grid">{hotels.map(h=>(<div className="card" key={h.id}><h4>{h.name}</h4><p>{h.city}</p></div>))}</div></div>)
}

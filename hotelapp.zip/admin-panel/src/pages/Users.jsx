import React, { useEffect, useState } from 'react'
import axios from 'axios'
export default function Users(){
  const [users,setUsers]=useState([])
  useEffect(()=>{ axios.get('/api/users').then(r=>setUsers(r.data)) },[])
  return (<div className="page"><h1>Users</h1><div className="grid">{users.map(u=>(<div className="card" key={u.id}><h4>{u.name}</h4><p>{u.email}</p></div>))}</div></div>)
}
